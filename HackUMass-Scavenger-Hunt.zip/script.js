let total_found = parseInt(getFromLocalStoreValue("stored_found"));

localStorage.getItem("stored_found", total_found)

function found() {
  updateLocalStoreValue("stored_found", total_found += 1);
  alert("you found " + total_found + " out of 9!");
  if (total_found == 9) {
    alert("You Win!")
    reset()
  }
}

function reset() {
  updateLocalStoreValue("stored_found", total_found = 0);
}

function updateLocalStoreValue(valueName, value) {
    if (typeof (Storage) !== "undefined") {
        localStorage.setItem(valueName, value);
    } else {
        alert("You have no local storage get rekt");
    }
}

function getFromLocalStoreValue(valueName) {
    if (typeof (Storage) !== "undefined") {
        return localStorage.getItem(valueName);
    }
}

// FINALLY ITS DONE THIS TOOK AGES //